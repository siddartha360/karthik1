# Design Guidelines: Aegis Support Pty Ltd - NDIS Provider Website

## Design Approach

**Reference-Based Approach**: Drawing inspiration from professional healthcare and disability services providers including inclusivendisprograms.com.au, with modern, trustworthy aesthetics that prioritize accessibility, clarity, and emotional connection. The design emphasizes credibility, warmth, and professionalism essential for NDIS service providers.

## Core Design Principles

1. **Accessibility-First**: WCAG 2.1 AA compliance throughout
2. **Trust & Professionalism**: Clean layouts that build confidence
3. **Warmth & Empathy**: Human-centered design with authentic imagery
4. **Clarity**: Information hierarchy that guides users effortlessly

## Typography System

**Font Families** (via Google Fonts CDN):
- Primary: 'Poppins' (headings, navigation, buttons)
- Secondary: 'Open Sans' (body text, descriptions)

**Type Scale**:
- Hero Headline: text-5xl md:text-6xl lg:text-7xl, font-bold
- Page Titles: text-4xl md:text-5xl, font-semibold
- Section Headings: text-3xl md:text-4xl, font-semibold
- Subsection Titles: text-2xl md:text-3xl, font-medium
- Card Titles: text-xl md:text-2xl, font-semibold
- Body Large: text-lg md:text-xl
- Body Regular: text-base md:text-lg
- Small Text: text-sm md:text-base

**Line Height**: leading-relaxed for body text, leading-tight for headings

## Layout System

**Spacing Units**: Tailwind units of 4, 6, 8, 12, 16, 20, 24, 32 (e.g., p-4, mt-8, mb-12, py-16, gap-6)

**Container Strategy**:
- Full-width sections: w-full with inner max-w-7xl mx-auto px-4 md:px-6 lg:px-8
- Content sections: max-w-6xl mx-auto
- Text-heavy content: max-w-4xl mx-auto
- Form sections: max-w-2xl mx-auto

**Grid Systems**:
- Service cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8
- Feature highlights: grid-cols-1 md:grid-cols-2 gap-8 md:gap-12
- Stats/Facts: grid-cols-2 md:grid-cols-4 gap-4 md:gap-6

**Section Padding**: 
- Desktop: py-20 md:py-24 lg:py-32
- Mobile: py-12 md:py-16

## Component Library

### Navigation Header
- Sticky header with backdrop-blur effect on scroll
- Logo left-aligned (height h-12 md:h-14)
- Horizontal navigation menu (hidden on mobile, hamburger menu)
- CTA button: "Book Consultation" - rounded-full with subtle shadow
- Mobile: Slide-in menu drawer from right

### Hero Section (Home Page)
- Height: min-h-[600px] md:min-h-[700px] lg:min-h-[800px]
- Large background image with overlay gradient
- Centered content: Company name, tagline, ABN
- Dual CTA buttons: Primary (solid) + Secondary (outline)
- Buttons with backdrop-blur-sm bg-white/20 treatment over image
- Subtle scroll indicator at bottom

### Service Cards (6-Grid Layout)
- Rounded corners: rounded-2xl
- Card elevation: shadow-lg hover:shadow-2xl transition
- Icon at top (h-12 w-12 md:h-16 w-16)
- Title: text-xl font-semibold
- Description: 2-3 lines, text-base
- Hover: subtle lift transform scale-105 transition-transform
- Border: border border-gray-100

### Process Steps (3-Step Section)
- Horizontal layout on desktop, vertical on mobile
- Step numbers in circles (h-16 w-16) with connecting lines
- Step title + description stacked
- Icons from Heroicons (outline style)

### Call-to-Action Sections
- Full-width with distinct background treatment
- Centered headline + supporting text
- Contact details: phone icon + number, email icon + address
- Primary CTA button: Large (px-8 py-4 text-lg)
- Spacing: py-16 md:py-20

### Content Sections (About, Services, NDIS Info)
- Alternating text-image layouts
- Images: rounded-xl with subtle shadow
- Text blocks: max-w-prose for readability
- Lists: Custom bullet points with check icons
- Subsections with clear visual separation (mb-12 md:mb-16)

### Team/Director Profile
- Card layout: rounded-2xl shadow-xl
- Profile image: rounded-full (h-32 w-32 md:h-40 w-40)
- Name: text-2xl font-bold
- Title: text-lg
- Bio: max-w-2xl mx-auto

### Forms (Contact, Careers)
- Input fields: rounded-lg border-2 focus:ring-2 transition
- Labels: text-sm font-medium mb-2
- Field spacing: space-y-6
- Submit button: Full-width on mobile, auto on desktop
- Form container: bg-white rounded-2xl shadow-xl p-8 md:p-12

### Contact Page Layout
- Two-column: Form (60%) + Info sidebar (40%)
- Map embed: h-96 rounded-xl mb-8
- Business hours with icon list
- Social links (if applicable)

### Footer
- Three-column layout (desktop): Company info | Quick links | Contact
- Single column (mobile)
- Logo + tagline
- Navigation links organized by category
- Contact information with icons
- NDIS logo/certification badges
- Copyright + Privacy Policy links
- Background: distinct from body, generous padding (py-12 md:py-16)

### Interactive Elements
- Buttons: rounded-full for primary actions, rounded-lg for secondary
- Hover states: subtle transform scale, shadow changes
- Focus states: ring-2 with offset for keyboard navigation
- Smooth transitions: transition-all duration-300
- No complex animations - subtle fades and transforms only

## Images Strategy

**Hero Section**: 
- Large hero image showing support worker assisting participant in bright, positive setting
- Overlay: gradient from transparent to semi-opaque
- Image should convey warmth, professionalism, care

**Service Section**: 
- Icon-based (Heroicons) rather than photos for consistency
- Optional: Small supporting images for major service categories

**About Us Page**:
- Director headshot: Professional, approachable
- Team photo: Diverse staff in professional setting
- Office/facility exterior (optional)

**Throughout Site**:
- Community participation activities
- Support workers assisting with daily tasks
- Participants engaged in recreational activities
- All images should show genuine smiles, diversity, real scenarios
- Prefer lifestyle imagery over stock-looking poses

**Image Treatment**:
- Rounded corners: rounded-xl or rounded-2xl
- Subtle shadows: shadow-lg
- Aspect ratios: 16:9 for wide images, 4:3 for portraits, 1:1 for profiles

## Responsive Behavior

**Breakpoints**:
- Mobile: Base (< 768px)
- Tablet: md (768px+)
- Desktop: lg (1024px+)
- Wide: xl (1280px+)

**Key Responsive Patterns**:
- Navigation: Hamburger menu < md, full menu >= md
- Grids: Stack to single column on mobile
- Hero text: Smaller on mobile, larger on desktop
- Images: Full-width mobile, constrained desktop
- Padding/margins: Reduced on mobile, generous on desktop
- Font sizes: Use responsive scale (text-base md:text-lg)

## Page-Specific Guidelines

**Home**: Hero + Intro + 6-Service Grid + Why Choose + 3-Step Process + CTA (6-8 sections)

**About Us**: Company Story + Mission/Vision/Values grid + Director Profile + Team section (if applicable)

**Services**: Service category sections with expandable descriptions, icon headers, supporting images

**NDIS Information**: Educational content with clear headings, lists, participant group cards, rights section

**Careers**: Available positions grid + benefits section + application form

**Contact**: Split layout (form + info), embedded map, business details with icons

This design creates a comprehensive, professional, and accessible NDIS provider website that builds trust while maintaining modern aesthetics and excellent usability across all devices.