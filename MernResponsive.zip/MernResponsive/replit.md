# Aegis Support - NDIS Provider Website

## Overview

Aegis Support Pty Ltd is a Queensland-based NDIS (National Disability Insurance Scheme) provider website built to deliver information about disability support services and enable participant engagement. The application is a full-stack web platform featuring a React-based frontend with shadcn/ui components and an Express backend with PostgreSQL database storage.

The website provides comprehensive information about NDIS services, company details, career opportunities, and facilitates contact inquiries and career applications through form submissions.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Tooling:**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server
- Wouter for lightweight client-side routing
- TanStack React Query for server state management and data fetching

**UI Component System:**
- shadcn/ui component library built on Radix UI primitives
- Tailwind CSS for utility-first styling with custom design tokens
- CSS variables for theming (light/dark mode support built-in)
- Custom design system following WCAG 2.1 AA accessibility standards

**Design Approach:**
- Typography: Google Fonts (Poppins for headings, Open Sans for body text)
- Responsive layouts with mobile-first approach
- Accessibility-first design with proper semantic HTML and ARIA labels
- Professional healthcare aesthetic inspired by disability services providers

**State Management:**
- React Query for async data fetching and caching
- Local component state with React hooks
- Form state managed through react-hook-form with Zod validation

### Backend Architecture

**Server Framework:**
- Express.js with TypeScript for type-safe API development
- RESTful API architecture for form submissions
- Middleware for JSON parsing, request logging, and error handling

**API Endpoints:**
- `POST /api/contact` - Contact inquiry submissions
- `POST /api/careers/apply` - Career application submissions

**In-Development Storage:**
- Currently using in-memory storage (MemStorage class) for development
- Interface-based storage abstraction (IStorage) allows easy swapping to persistent storage
- Prepared for PostgreSQL integration via Drizzle ORM

### Data Storage Solutions

**Database Schema (via Drizzle ORM):**
- PostgreSQL as the target database (Neon serverless)
- Three primary tables defined:
  - `users` - User authentication (prepared for future admin features)
  - `contact_inquiries` - Contact form submissions
  - `career_applications` - Career application submissions

**ORM & Validation:**
- Drizzle ORM for type-safe database queries
- Drizzle-Zod integration for automatic schema validation
- Zod schemas for runtime validation of form inputs
- UUID-based primary keys with PostgreSQL's `gen_random_uuid()`

**Migration Strategy:**
- Drizzle Kit for schema migrations
- Configuration points to PostgreSQL via DATABASE_URL environment variable
- Schema-first development with TypeScript types inferred from database schema

### Key Architectural Decisions

**1. Monorepo Structure**
- **Problem:** Need to share TypeScript types and schemas between frontend and backend
- **Solution:** Organized as a monorepo with shared schema definitions in `/shared` directory
- **Rationale:** Enables type safety across the full stack and reduces code duplication

**2. Storage Abstraction Layer**
- **Problem:** Need to develop without database during early stages while preparing for production
- **Solution:** IStorage interface with MemStorage implementation for development
- **Rationale:** Allows immediate development while database is being provisioned, easy migration path to PostgreSQL

**3. Form Validation Strategy**
- **Problem:** Need consistent validation between client and server
- **Solution:** Shared Zod schemas derived from Drizzle database schema
- **Rationale:** Single source of truth for data validation, automatic type inference, runtime safety

**4. Component Library Selection**
- **Problem:** Need accessible, customizable UI components quickly
- **Solution:** shadcn/ui built on Radix UI primitives
- **Rationale:** Provides accessible components by default, fully customizable through Tailwind, no external runtime dependencies

**5. Static Asset Handling**
- **Problem:** Need to serve generated images and design assets
- **Solution:** Vite alias for `@assets` directory pointing to `attached_assets`
- **Rationale:** Simple static file serving with type-safe imports in development

## External Dependencies

### Core Services
- **Neon Database** - Serverless PostgreSQL database (@neondatabase/serverless)
  - Connection via DATABASE_URL environment variable
  - Serverless architecture for automatic scaling

### UI & Component Libraries
- **Radix UI** - Unstyled, accessible component primitives
  - Full suite of components (accordion, dialog, dropdown, navigation, etc.)
  - WCAG compliance built-in
  
- **shadcn/ui** - Pre-styled component library
  - Built on Radix UI
  - Customized through Tailwind CSS

### Styling & Design
- **Tailwind CSS** - Utility-first CSS framework
  - Custom design tokens via CSS variables
  - PostCSS for processing
  
- **Google Fonts** - Typography
  - Poppins (headings)
  - Open Sans (body text)

### Development Tools
- **Vite** - Build tool and dev server
  - Hot Module Replacement (HMR)
  - Optimized production builds
  
- **Replit Plugins** - Development enhancements
  - Runtime error overlay
  - Cartographer for code navigation
  - Development banner

### Form Handling & Validation
- **react-hook-form** - Form state management
- **Zod** - Schema validation
  - @hookform/resolvers for integration

### Data Fetching
- **TanStack React Query** - Server state management
  - Automatic caching
  - Background refetching
  - Optimistic updates

### Routing
- **Wouter** - Lightweight React router
  - Client-side routing
  - Small bundle size alternative to React Router

### Database & ORM
- **Drizzle ORM** - TypeScript ORM
  - Type-safe queries
  - Schema migrations via drizzle-kit
  - PostgreSQL dialect
  
- **drizzle-zod** - Schema validation integration

### Build & Runtime
- **esbuild** - Server bundling for production
- **tsx** - TypeScript execution for development