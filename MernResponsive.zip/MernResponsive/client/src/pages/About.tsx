import { Card } from "@/components/ui/card";
import { Award, Heart, Users, Target } from "lucide-react";
import CTASection from "@/components/CTASection";
import directorImage from "@assets/generated_images/professional_director_headshot_portrait_7f9ebc94.png";

export default function AboutPage() {
  const values = [
    {
      icon: Heart,
      title: "Respect",
      description: "Every participant deserves dignity.",
    },
    {
      icon: Award,
      title: "Integrity",
      description: "Honesty and transparency guide everything we do.",
    },
    {
      icon: Users,
      title: "Empathy",
      description: "We care from the heart.",
    },
    {
      icon: Target,
      title: "Excellence",
      description: "Striving for continuous improvement and compliance.",
    },
  ];

  return (
    <>
      <section className="py-16 md:py-24 bg-accent/20">
        <div className="max-w-4xl mx-auto px-4 md:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-heading mb-6">
            About Aegis Support
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground font-body">
            Delivering compassionate, high-quality disability support across Queensland
          </p>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-background">
        <div className="max-w-6xl mx-auto px-4 md:px-6 lg:px-8">
          <div className="mb-16">
            <h2 className="text-3xl md:text-4xl font-bold font-heading mb-6">Our Story</h2>
            <p className="text-lg md:text-xl text-muted-foreground font-body leading-relaxed mb-4">
              Founded by <span className="font-semibold text-foreground">Karthik Jella</span>, Aegis Support Pty Ltd was created with the vision of delivering compassionate, high-quality disability support across Queensland.
            </p>
            <p className="text-lg md:text-xl text-muted-foreground font-body leading-relaxed">
              We believe every person deserves the opportunity to live independently and confidently within their community.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 mb-16">
            <Card className="p-8 md:p-10">
              <h3 className="text-2xl md:text-3xl font-bold font-heading mb-4">Mission Statement</h3>
              <p className="text-lg text-muted-foreground font-body leading-relaxed">
                To provide reliable and person-centred disability support that enhances independence, inclusion, and wellbeing.
              </p>
            </Card>

            <Card className="p-8 md:p-10">
              <h3 className="text-2xl md:text-3xl font-bold font-heading mb-4">Vision</h3>
              <p className="text-lg text-muted-foreground font-body leading-relaxed">
                A world where individuals with disabilities live freely, confidently, and without barriers.
              </p>
            </Card>
          </div>

          <div className="mb-16">
            <h2 className="text-3xl md:text-4xl font-bold font-heading mb-8 text-center">Our Values</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {values.map((value, index) => (
                <Card key={index} className="p-6 text-center hover-elevate transition-all">
                  <div className="flex justify-center mb-4">
                    <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center">
                      <value.icon className="h-7 w-7 text-primary" />
                    </div>
                  </div>
                  <h4 className="text-xl font-semibold font-heading mb-2">{value.title}</h4>
                  <p className="text-sm text-muted-foreground font-body">{value.description}</p>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-accent/20">
        <div className="max-w-4xl mx-auto px-4 md:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold font-heading mb-12 text-center">
            Meet the Director
          </h2>
          
          <Card className="p-8 md:p-12 shadow-2xl">
            <div className="flex flex-col md:flex-row gap-8 items-center md:items-start">
              <div className="flex-shrink-0">
                <img
                  src={directorImage}
                  alt="Karthik Jella - Director"
                  className="h-40 w-40 rounded-full object-cover shadow-lg"
                />
              </div>
              
              <div className="flex-1 text-center md:text-left">
                <h3 className="text-2xl md:text-3xl font-bold font-heading mb-2">
                  Karthik Jella
                </h3>
                <p className="text-lg text-primary font-medium mb-4">
                  Founder & Managing Director
                </p>
                <p className="text-base md:text-lg text-muted-foreground font-body leading-relaxed">
                  Karthik brings a strong commitment to participant care, staff training, and maintaining NDIS quality standards. Under his leadership, Aegis Support continues to uphold the highest levels of safety and service delivery.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </section>

      <CTASection
        title="Join us in empowering lives"
        description="Learn more about our services or get in touch to discuss how we can support you."
        primaryButtonText="Contact Us"
        primaryButtonLink="/contact"
        secondaryButtonText="View Services"
        secondaryButtonLink="/services"
      />
    </>
  );
}
