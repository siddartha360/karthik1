import { Card } from "@/components/ui/card";

export default function PrivacyPage() {
  return (
    <>
      <section className="py-16 md:py-24 bg-accent/20">
        <div className="max-w-4xl mx-auto px-4 md:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-heading mb-6">
            Privacy Policy
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground font-body">
            Your privacy and data security are our top priorities
          </p>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-background">
        <div className="max-w-4xl mx-auto px-4 md:px-6 lg:px-8">
          <Card className="p-8 md:p-12">
            <div className="prose max-w-none">
              <p className="text-lg text-muted-foreground font-body leading-relaxed mb-8">
                Aegis Support Pty Ltd respects your privacy and follows the <span className="font-semibold text-foreground">Australian Privacy Principles</span> and <span className="font-semibold text-foreground">NDIS Code of Conduct</span>. All personal information is collected and stored securely.
              </p>

              <h2 className="text-2xl font-bold font-heading mb-4">Information Collection</h2>
              <p className="text-base text-muted-foreground font-body leading-relaxed mb-6">
                We collect personal information necessary to provide NDIS services, including contact details, medical information, and support needs. This information is only collected with your consent and is used solely for service delivery purposes.
              </p>

              <h2 className="text-2xl font-bold font-heading mb-4">Data Security</h2>
              <p className="text-base text-muted-foreground font-body leading-relaxed mb-6">
                Your information is stored securely using industry-standard encryption and access controls. Only authorized staff members have access to your personal information, and all staff are trained in privacy and confidentiality requirements.
              </p>

              <h2 className="text-2xl font-bold font-heading mb-4">Your Rights</h2>
              <p className="text-base text-muted-foreground font-body leading-relaxed mb-6">
                You have the right to access, correct, or request deletion of your personal information at any time. Contact us to exercise these rights or if you have any privacy concerns.
              </p>

              <h2 className="text-2xl font-bold font-heading mb-4">Contact Us</h2>
              <p className="text-base text-muted-foreground font-body leading-relaxed">
                For privacy-related inquiries, please contact us at <a href="mailto:aegis.spt@gmail.com" className="text-primary hover:underline">aegis.spt@gmail.com</a> or call <a href="tel:0435767872" className="text-primary hover:underline">04 3576 7872</a>.
              </p>
            </div>
          </Card>
        </div>
      </section>
    </>
  );
}
