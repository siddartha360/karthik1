import { Card } from "@/components/ui/card";
import CTASection from "@/components/CTASection";
import { CheckCircle, Shield, Heart, Users, Brain, Activity } from "lucide-react";

export default function NDISInfoPage() {
  const participantGroups = [
    {
      icon: Brain,
      title: "Autism Spectrum Disorder (ASD)",
    },
    {
      icon: Users,
      title: "Intellectual and Physical Disabilities",
    },
    {
      icon: Activity,
      title: "Acquired Brain Injury",
    },
    {
      icon: Heart,
      title: "Dementia & Mental Health",
    },
    {
      icon: Shield,
      title: "Spinal Injury and Ventilator Dependency",
    },
  ];

  const ageGroups = [
    "0–6 years",
    "7–16 years",
    "17–65 years",
    "Over 65 years",
  ];

  return (
    <>
      <section className="py-16 md:py-24 bg-accent/20">
        <div className="max-w-4xl mx-auto px-4 md:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-heading mb-6">
            NDIS Information
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground font-body">
            Understanding the National Disability Insurance Scheme
          </p>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-background">
        <div className="max-w-6xl mx-auto px-4 md:px-6 lg:px-8">
          <div className="mb-16">
            <h2 className="text-3xl md:text-4xl font-bold font-heading mb-6">
              What is the NDIS?
            </h2>
            <Card className="p-8 md:p-10">
              <p className="text-lg md:text-xl text-muted-foreground font-body leading-relaxed">
                The National Disability Insurance Scheme (NDIS) supports Australians with permanent and significant disabilities by funding the services and supports they need to live an independent life.
              </p>
            </Card>
          </div>

          <div className="mb-16">
            <h2 className="text-3xl md:text-4xl font-bold font-heading mb-6">
              How We Help
            </h2>
            <Card className="p-8 md:p-10">
              <p className="text-lg md:text-xl text-muted-foreground font-body leading-relaxed">
                Aegis Support Pty Ltd partners with participants, families, and coordinators to deliver personalised services aligned with your NDIS goals. We work closely with you to ensure every service is tailored to your unique needs.
              </p>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-accent/20">
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold font-heading mb-12 text-center">
            Participant Groups We Support
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {participantGroups.map((group, index) => (
              <Card key={index} className="p-6 hover-elevate transition-all">
                <div className="flex items-start gap-4">
                  <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <group.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold font-heading">{group.title}</h3>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          <div className="max-w-4xl mx-auto">
            <h3 className="text-2xl md:text-3xl font-bold font-heading mb-6 text-center">
              Age Groups Supported
            </h3>
            <Card className="p-8">
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {ageGroups.map((age, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-primary flex-shrink-0" />
                    <span className="text-base font-body">{age}</span>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-background">
        <div className="max-w-6xl mx-auto px-4 md:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold font-heading mb-8 text-center">
            Your Rights & Safety
          </h2>

          <Card className="p-8 md:p-12">
            <div className="max-w-4xl mx-auto">
              <p className="text-lg md:text-xl text-muted-foreground font-body leading-relaxed mb-8">
                We are fully compliant with the <span className="font-semibold text-foreground">NDIS Quality and Safeguards Commission</span> requirements.
              </p>

              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
                  <p className="text-base md:text-lg font-body">
                    All staff are background checked and trained in participant rights
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
                  <p className="text-base md:text-lg font-body">
                    Comprehensive medication management protocols
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
                  <p className="text-base md:text-lg font-body">
                    Emergency response procedures in place
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
                  <p className="text-base md:text-lg font-body">
                    Continuous quality improvement and compliance monitoring
                  </p>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </section>

      <CTASection
        title="Questions about the NDIS?"
        description="Our team is here to help you understand your options and access the support you need."
        primaryButtonText="Contact Us"
        primaryButtonLink="/contact"
        secondaryButtonText="View Our Services"
        secondaryButtonLink="/services"
      />
    </>
  );
}
