import ServiceCard from "@/components/ServiceCard";
import CTASection from "@/components/CTASection";
import { Heart, Car, Home, Users, Lightbulb, TrendingUp, UserPlus, Briefcase, Brain } from "lucide-react";
import lifeSkillsImage from "@assets/generated_images/life_skills_development_and_training_2ecd5bda.png";

export default function ServicesPage() {
  const services = [
    {
      icon: Heart,
      title: "Assist Personal Activities",
      code: "0107",
      description: "Help with personal tasks such as showering, grooming, dressing, and eating.",
    },
    {
      icon: Car,
      title: "Assist Travel/Transport",
      code: "0108",
      description: "Safe, punctual travel to medical appointments, workplaces, and community activities.",
    },
    {
      icon: Home,
      title: "Household Tasks",
      code: "0120",
      description: "Cleaning, washing, meal preparation, and light home maintenance.",
    },
    {
      icon: Users,
      title: "Daily Tasks/Shared Living",
      code: "0115",
      description: "Assistance with shared or independent living environments.",
    },
    {
      icon: Lightbulb,
      title: "Development Life Skills",
      code: "0117",
      description: "Support for learning everyday life skills — budgeting, cooking, communication.",
    },
    {
      icon: TrendingUp,
      title: "Assist Life Stage, Transition",
      code: "0106",
      description: "Guidance and planning for life changes, such as employment, relocation, or new routines.",
    },
    {
      icon: UserPlus,
      title: "Community Participation",
      code: "0125 / 0136",
      description: "Join social, recreational, and educational activities in your local community.",
    },
    {
      icon: Briefcase,
      title: "Specialised Supported Employment",
      code: "0133",
      description: "Meaningful employment opportunities tailored for participants with disabilities.",
    },
    {
      icon: Brain,
      title: "Behaviour Support",
      code: "Module 2A",
      description: "Development and implementation of behaviour support plans.",
    },
  ];

  return (
    <>
      <section className="py-16 md:py-24 bg-accent/20">
        <div className="max-w-4xl mx-auto px-4 md:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-heading mb-6">
            Our Services
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground font-body">
            Comprehensive NDIS support tailored to your individual needs
          </p>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
          <div className="mb-12">
            <h2 className="text-3xl md:text-4xl font-bold font-heading mb-4 text-center">
              Core NDIS Supports
            </h2>
            <p className="text-lg text-muted-foreground font-body text-center max-w-3xl mx-auto">
              We provide a full range of NDIS services to support your independence and quality of life
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {services.map((service, index) => (
              <ServiceCard key={index} {...service} />
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-accent/20">
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src={lifeSkillsImage}
                alt="Life skills development"
                className="rounded-2xl shadow-2xl w-full"
              />
            </div>
            
            <div>
              <h2 className="text-3xl md:text-4xl font-bold font-heading mb-6">
                Personalized Support Plans
              </h2>
              <p className="text-lg md:text-xl text-muted-foreground font-body leading-relaxed mb-6">
                Every participant is unique, and so are our support plans. We work closely with you to understand your goals and design services that truly make a difference.
              </p>
              <p className="text-lg md:text-xl text-muted-foreground font-body leading-relaxed">
                Our experienced team ensures that you receive the right support at the right time, helping you achieve greater independence and participate fully in your community.
              </p>
            </div>
          </div>
        </div>
      </section>

      <CTASection
        title="Ready to explore our services?"
        description="Contact us today to discuss which services are right for you."
        primaryButtonText="Get in Touch"
        primaryButtonLink="/contact"
        secondaryButtonText="NDIS Information"
        secondaryButtonLink="/ndis-info"
      />
    </>
  );
}
