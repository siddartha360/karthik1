import Hero from "@/components/Hero";
import ServiceCard from "@/components/ServiceCard";
import ProcessStep from "@/components/ProcessStep";
import CTASection from "@/components/CTASection";
import { Heart, Home, Users, Lightbulb, Car, Brain, MessageCircle, FileText, Rocket, CheckCircle } from "lucide-react";
import { Card } from "@/components/ui/card";
import communityImage from "@assets/generated_images/community_participation_and_inclusion_activities_c7f2c451.png";

export default function HomePage() {
  const coreServices = [
    {
      icon: Heart,
      title: "Assist Personal Activities",
      description: "Support with daily personal routines.",
    },
    {
      icon: Home,
      title: "Household Tasks",
      description: "Cleaning, cooking, and home upkeep.",
    },
    {
      icon: Users,
      title: "Community Participation",
      description: "Build social and community connections.",
    },
    {
      icon: Lightbulb,
      title: "Development Life Skills",
      description: "Training in communication, budgeting, and more.",
    },
    {
      icon: Car,
      title: "Travel & Transport Assistance",
      description: "Safe and reliable travel for appointments.",
    },
    {
      icon: Brain,
      title: "Behaviour Support",
      description: "Positive behaviour strategies for better wellbeing.",
    },
  ];

  const whyChoosePoints = [
    "Compassionate & qualified staff",
    "Participant-first approach",
    "Flexible service delivery",
    "NDIS Practice Standards compliant",
    "Safe, respectful, and reliable care",
  ];

  return (
    <>
      <Hero />

      <section className="py-16 md:py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold font-heading mb-6">
                Who We Are
              </h2>
              <p className="text-lg md:text-xl text-muted-foreground font-body leading-relaxed mb-6">
                <span className="font-semibold text-foreground">Aegis Support Pty Ltd</span> is a Queensland-based NDIS provider committed to improving the quality of life for people with disabilities.
              </p>
              <p className="text-lg md:text-xl text-muted-foreground font-body leading-relaxed mb-8">
                We empower participants to live independently, achieve their goals, and participate actively in the community.
              </p>
              
              <div className="space-y-3">
                <h3 className="text-xl font-semibold font-heading mb-4">Quick Facts:</h3>
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                  <span className="text-base">Based in Park Avenue, QLD</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                  <span className="text-base">Fully certified NDIS Provider</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                  <span className="text-base">Serving participants of all ages and abilities</span>
                </div>
              </div>
            </div>

            <div className="relative">
              <img
                src={communityImage}
                alt="Community participation"
                className="rounded-2xl shadow-2xl w-full"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-accent/20">
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
          <div className="text-center mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold font-heading mb-4">
              Our Core Services
            </h2>
            <p className="text-lg md:text-xl text-muted-foreground font-body max-w-3xl mx-auto">
              Comprehensive NDIS support designed to enhance your independence and quality of life
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 mb-12">
            {coreServices.map((service, index) => (
              <ServiceCard key={index} {...service} />
            ))}
          </div>

          <div className="text-center">
            <a href="/services" className="inline-block">
              <button className="px-8 py-3 bg-primary text-primary-foreground rounded-full hover-elevate font-medium text-base transition-all" data-testid="button-view-all-services">
                View All Services
              </button>
            </a>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-background">
        <div className="max-w-6xl mx-auto px-4 md:px-6 lg:px-8">
          <div className="text-center mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold font-heading mb-4">
              Why Choose Aegis Support
            </h2>
          </div>

          <Card className="p-8 md:p-12">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {whyChoosePoints.map((point, index) => (
                <div key={index} className="flex items-start gap-3">
                  <CheckCircle className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
                  <span className="text-base md:text-lg font-body">{point}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-accent/20">
        <div className="max-w-6xl mx-auto px-4 md:px-6 lg:px-8">
          <div className="text-center mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold font-heading mb-4">
              NDIS Participant Pathway
            </h2>
            <p className="text-lg md:text-xl text-muted-foreground font-body max-w-3xl mx-auto">
              Your journey to independence starts here
            </p>
          </div>

          <div className="space-y-0">
            <ProcessStep
              number={1}
              icon={MessageCircle}
              title="Connect with Us"
              description="Contact our friendly team to discuss your goals."
            />
            <ProcessStep
              number={2}
              icon={FileText}
              title="Plan Your Supports"
              description="We design a personalised NDIS plan that fits your needs."
            />
            <ProcessStep
              number={3}
              icon={Rocket}
              title="Start Your Journey"
              description="Receive quality care and continuous progress tracking."
              isLast
            />
          </div>
        </div>
      </section>

      <CTASection
        title="Ready to begin your NDIS journey with Aegis Support?"
        primaryButtonText="Book a Consultation"
        primaryButtonLink="/contact"
        secondaryButtonText="Learn More"
        secondaryButtonLink="/about"
      />
    </>
  );
}
