import HomePage from '../Home';

export default function HomeExample() {
  return <HomePage />;
}
