import PrivacyPage from '../Privacy';

export default function PrivacyExample() {
  return <PrivacyPage />;
}
