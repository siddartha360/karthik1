import ContactPage from '../Contact';

export default function ContactExample() {
  return <ContactPage />;
}
