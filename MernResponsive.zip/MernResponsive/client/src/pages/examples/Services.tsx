import ServicesPage from '../Services';

export default function ServicesExample() {
  return <ServicesPage />;
}
