import CareersPage from '../Careers';

export default function CareersExample() {
  return <CareersPage />;
}
