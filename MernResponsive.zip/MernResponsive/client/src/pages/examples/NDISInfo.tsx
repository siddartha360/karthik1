import NDISInfoPage from '../NDISInfo';

export default function NDISInfoExample() {
  return <NDISInfoPage />;
}
