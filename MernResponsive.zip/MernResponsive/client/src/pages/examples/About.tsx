import AboutPage from '../About';

export default function AboutExample() {
  return <AboutPage />;
}
