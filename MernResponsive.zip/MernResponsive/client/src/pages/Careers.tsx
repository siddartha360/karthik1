import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { CheckCircle, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function CareersPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    position: "",
    message: "",
  });

  const { toast } = useToast();

  const roles = [
    "Disability Support Workers",
    "Behaviour Support Practitioners",
    "Allied Health Professionals",
    "Administrative Staff",
  ];

  const benefits = [
    "Supportive work culture",
    "Ongoing training and development",
    "Flexible hours",
    "Opportunities for growth",
    "Competitive remuneration",
    "Make a real difference",
  ];

  const careerMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return await apiRequest("POST", "/api/careers/apply", data);
    },
    onSuccess: () => {
      toast({
        title: "Application Submitted",
        description: "We'll review your application and get back to you soon.",
      });
      setFormData({ name: "", email: "", phone: "", position: "", message: "" });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit application. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    careerMutation.mutate(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <>
      <section className="py-16 md:py-24 bg-accent/20">
        <div className="max-w-4xl mx-auto px-4 md:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-heading mb-6">
            Join the Aegis Team
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground font-body">
            Are you passionate about making a difference?
          </p>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-background">
        <div className="max-w-6xl mx-auto px-4 md:px-6 lg:px-8">
          <div className="mb-16">
            <Card className="p-8 md:p-10">
              <p className="text-lg md:text-xl text-muted-foreground font-body leading-relaxed text-center max-w-4xl mx-auto">
                Aegis Support is always looking for skilled, caring, and motivated individuals to join our growing team. If you're committed to improving lives and supporting independence, we'd love to hear from you.
              </p>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-12 mb-16">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold font-heading mb-8">
                Available Roles
              </h2>
              <div className="space-y-3">
                {roles.map((role, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <CheckCircle className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
                    <span className="text-lg font-body">{role}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h2 className="text-3xl md:text-4xl font-bold font-heading mb-8">
                Why Work With Us
              </h2>
              <div className="space-y-3">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <CheckCircle className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
                    <span className="text-lg font-body">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-accent/20">
        <div className="max-w-3xl mx-auto px-4 md:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold font-heading mb-4">
              Apply Now
            </h2>
            <p className="text-lg text-muted-foreground font-body">
              Send your resume to <a href="mailto:aegis.spt@gmail.com" className="text-primary font-medium hover:underline">aegis.spt@gmail.com</a> or fill out the form below
            </p>
          </div>

          <Card className="p-8 md:p-12 shadow-2xl">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="name" className="text-base mb-2">Full Name *</Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="rounded-lg"
                  data-testid="input-career-name"
                />
              </div>

              <div>
                <Label htmlFor="email" className="text-base mb-2">Email Address *</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="rounded-lg"
                  data-testid="input-career-email"
                />
              </div>

              <div>
                <Label htmlFor="phone" className="text-base mb-2">Phone Number *</Label>
                <Input
                  id="phone"
                  name="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                  className="rounded-lg"
                  data-testid="input-career-phone"
                />
              </div>

              <div>
                <Label htmlFor="position" className="text-base mb-2">Position Applying For *</Label>
                <Input
                  id="position"
                  name="position"
                  value={formData.position}
                  onChange={handleChange}
                  required
                  className="rounded-lg"
                  data-testid="input-career-position"
                />
              </div>

              <div>
                <Label htmlFor="message" className="text-base mb-2">Cover Letter / Message</Label>
                <Textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={6}
                  className="rounded-lg resize-none"
                  placeholder="Tell us why you'd like to join the Aegis team..."
                  data-testid="input-career-message"
                />
              </div>

              <div className="border-2 border-dashed rounded-lg p-8 text-center hover-elevate cursor-pointer transition-all">
                <Upload className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                <p className="text-sm text-muted-foreground mb-1">Upload your resume (PDF, DOC, DOCX)</p>
                <p className="text-xs text-muted-foreground">Or email directly to aegis.spt@gmail.com</p>
              </div>

              <Button 
                type="submit" 
                size="lg" 
                className="w-full rounded-full" 
                disabled={careerMutation.isPending}
                data-testid="button-submit-application"
              >
                {careerMutation.isPending ? "Submitting..." : "Submit Application"}
              </Button>
            </form>
          </Card>
        </div>
      </section>
    </>
  );
}
