import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Phone } from "lucide-react";
import heroImage from "@assets/generated_images/caring_support_worker_with_elderly_participant_d8222ec0.png";

export default function Hero() {
  return (
    <section className="relative min-h-[600px] md:min-h-[700px] lg:min-h-[800px] flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img
          src={heroImage}
          alt="Support worker assisting participant"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-black/30"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-20 text-center md:text-left">
        <div className="max-w-3xl">
          <h1 className="text-4xl md:text-5xl lg:text-7xl font-bold text-white mb-4 md:mb-6 font-heading leading-tight">
            Empowering Lives.<br />Supporting Independence.
          </h1>
          
          <p className="text-lg md:text-xl lg:text-2xl text-white/90 mb-3 font-body">
            Registered NDIS Provider – Aegis Support Pty Ltd
          </p>
          
          <p className="text-base md:text-lg text-white/80 mb-8 font-body">
            ABN 80 691 758 479
          </p>

          <div className="flex flex-col sm:flex-row gap-4 mb-8">
            <Link href="/contact">
              <Button size="lg" className="rounded-full text-base md:text-lg px-8 w-full sm:w-auto" data-testid="button-hero-contact">
                Contact Us
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/services">
              <Button 
                size="lg" 
                variant="outline" 
                className="rounded-full text-base md:text-lg px-8 backdrop-blur-sm bg-white/10 text-white border-white/30 hover:bg-white/20 w-full sm:w-auto"
                data-testid="button-hero-services"
              >
                Explore Services
              </Button>
            </Link>
          </div>

          <a href="tel:0435767872" className="inline-flex items-center gap-2 text-white hover-elevate px-4 py-2 rounded-lg backdrop-blur-sm bg-white/10">
            <Phone className="h-5 w-5" />
            <span className="text-lg font-medium">04 3576 7872</span>
          </a>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 hidden md:block">
        <div className="animate-bounce">
          <div className="w-6 h-10 border-2 border-white/50 rounded-full flex items-start justify-center p-2">
            <div className="w-1 h-3 bg-white/70 rounded-full"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
