import { LucideIcon } from "lucide-react";
import { Card } from "@/components/ui/card";

interface ServiceCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  code?: string;
}

export default function ServiceCard({ icon: Icon, title, description, code }: ServiceCardProps) {
  return (
    <Card className="p-6 md:p-8 hover-elevate transition-all duration-300 hover:shadow-xl border-border" data-testid={`card-service-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <div className="flex flex-col items-center text-center space-y-4">
        <div className="h-14 w-14 md:h-16 md:w-16 rounded-full bg-primary/10 flex items-center justify-center">
          <Icon className="h-7 w-7 md:h-8 md:w-8 text-primary" />
        </div>
        
        <div>
          <h3 className="text-xl md:text-2xl font-semibold font-heading mb-2">
            {title}
          </h3>
          {code && (
            <p className="text-xs text-muted-foreground mb-2 font-mono">{code}</p>
          )}
          <p className="text-base text-muted-foreground font-body leading-relaxed">
            {description}
          </p>
        </div>
      </div>
    </Card>
  );
}
