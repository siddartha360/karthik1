import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Phone, Mail, ArrowRight } from "lucide-react";

interface CTASectionProps {
  title: string;
  description?: string;
  showContact?: boolean;
  primaryButtonText?: string;
  primaryButtonLink?: string;
  secondaryButtonText?: string;
  secondaryButtonLink?: string;
  bgVariant?: "default" | "accent";
}

export default function CTASection({
  title,
  description,
  showContact = true,
  primaryButtonText = "Get Started",
  primaryButtonLink = "/contact",
  secondaryButtonText,
  secondaryButtonLink,
  bgVariant = "accent"
}: CTASectionProps) {
  return (
    <section className={`py-16 md:py-20 ${bgVariant === "accent" ? "bg-accent/30" : "bg-background"}`}>
      <div className="max-w-4xl mx-auto px-4 md:px-6 lg:px-8 text-center">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold font-heading mb-4">
          {title}
        </h2>
        
        {description && (
          <p className="text-lg md:text-xl text-muted-foreground font-body mb-8 max-w-2xl mx-auto">
            {description}
          </p>
        )}

        {showContact && (
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
            <a href="tel:0435767872" className="flex items-center gap-2 text-lg hover-elevate px-4 py-2 rounded-lg" data-testid="link-cta-phone">
              <Phone className="h-5 w-5 text-primary" />
              <span className="font-medium">04 3576 7872</span>
            </a>
            <span className="hidden sm:block text-muted-foreground">|</span>
            <a href="mailto:aegis.spt@gmail.com" className="flex items-center gap-2 text-lg hover-elevate px-4 py-2 rounded-lg" data-testid="link-cta-email">
              <Mail className="h-5 w-5 text-primary" />
              <span className="font-medium">aegis.spt@gmail.com</span>
            </a>
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href={primaryButtonLink}>
            <Button size="lg" className="rounded-full px-8 w-full sm:w-auto" data-testid="button-cta-primary">
              {primaryButtonText}
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
          {secondaryButtonText && secondaryButtonLink && (
            <Link href={secondaryButtonLink}>
              <Button size="lg" variant="outline" className="rounded-full px-8 w-full sm:w-auto" data-testid="button-cta-secondary">
                {secondaryButtonText}
              </Button>
            </Link>
          )}
        </div>
      </div>
    </section>
  );
}
