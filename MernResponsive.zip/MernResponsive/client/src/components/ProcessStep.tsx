import { LucideIcon } from "lucide-react";

interface ProcessStepProps {
  number: number;
  icon: LucideIcon;
  title: string;
  description: string;
  isLast?: boolean;
}

export default function ProcessStep({ number, icon: Icon, title, description, isLast = false }: ProcessStepProps) {
  return (
    <div className="relative flex flex-col md:flex-row items-center md:items-start gap-6">
      <div className="flex flex-col items-center">
        <div className="relative z-10 h-16 w-16 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-2xl font-bold font-heading shadow-lg">
          {number}
        </div>
        {!isLast && (
          <div className="hidden md:block absolute top-16 left-8 w-0.5 h-full bg-border"></div>
        )}
      </div>

      <div className="flex-1 text-center md:text-left pb-12 md:pb-0">
        <div className="mb-4 flex justify-center md:justify-start">
          <div className="h-12 w-12 rounded-full bg-accent flex items-center justify-center">
            <Icon className="h-6 w-6 text-accent-foreground" />
          </div>
        </div>
        <h3 className="text-2xl md:text-3xl font-semibold font-heading mb-3">{title}</h3>
        <p className="text-base md:text-lg text-muted-foreground font-body leading-relaxed max-w-md mx-auto md:mx-0">
          {description}
        </p>
      </div>
    </div>
  );
}
