import CTASection from '../CTASection';

export default function CTASectionExample() {
  return (
    <CTASection
      title="Ready to begin your NDIS journey with Aegis Support?"
      primaryButtonText="Book a Consultation"
      secondaryButtonText="Learn More"
      secondaryButtonLink="/about"
    />
  );
}
