import ProcessStep from '../ProcessStep';
import { MessageCircle } from 'lucide-react';

export default function ProcessStepExample() {
  return (
    <div className="p-8 bg-background">
      <ProcessStep
        number={1}
        icon={MessageCircle}
        title="Connect with Us"
        description="Contact our friendly team to discuss your goals."
      />
    </div>
  );
}
