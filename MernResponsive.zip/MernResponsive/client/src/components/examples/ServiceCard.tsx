import ServiceCard from '../ServiceCard';
import { Heart } from 'lucide-react';

export default function ServiceCardExample() {
  return (
    <div className="p-8 bg-background">
      <ServiceCard
        icon={Heart}
        title="Assist Personal Activities"
        description="Support with daily personal routines."
        code="0107"
      />
    </div>
  );
}
