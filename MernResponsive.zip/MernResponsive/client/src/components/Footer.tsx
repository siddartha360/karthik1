import { Link } from "wouter";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-card border-t">
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12">
          <div>
            <h3 className="text-xl font-bold font-heading text-primary mb-4">Aegis Support</h3>
            <p className="text-sm text-muted-foreground font-body mb-4 leading-relaxed">
              Registered NDIS Provider committed to improving quality of life for people with disabilities.
            </p>
            <p className="text-xs text-muted-foreground">ABN 80 691 758 479</p>
          </div>

          <div>
            <h4 className="text-base font-semibold font-heading mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/services" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Our Services
                </Link>
              </li>
              <li>
                <Link href="/ndis-info" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  NDIS Information
                </Link>
              </li>
              <li>
                <Link href="/careers" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Careers
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-base font-semibold font-heading mb-4">Services</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Personal Activities</li>
              <li>Household Tasks</li>
              <li>Community Participation</li>
              <li>Life Skills Development</li>
              <li>Travel & Transport</li>
              <li>Behaviour Support</li>
            </ul>
          </div>

          <div>
            <h4 className="text-base font-semibold font-heading mb-4">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0 text-primary" />
                <span>Unit 4, 16 Kerr Street, Park Avenue, QLD 4701</span>
              </li>
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Phone className="h-4 w-4 flex-shrink-0 text-primary" />
                <a href="tel:0435767872" className="hover:text-primary transition-colors">04 3576 7872</a>
              </li>
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Mail className="h-4 w-4 flex-shrink-0 text-primary" />
                <a href="mailto:aegis.spt@gmail.com" className="hover:text-primary transition-colors">aegis.spt@gmail.com</a>
              </li>
              <li className="flex items-start gap-2 text-sm text-muted-foreground">
                <Clock className="h-4 w-4 mt-0.5 flex-shrink-0 text-primary" />
                <span>Mon-Fri: 9:00 AM - 5:00 PM</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-muted-foreground text-center md:text-left">
              © {currentYear} Aegis Support Pty Ltd. All rights reserved.
            </p>
            <div className="flex gap-6">
              <Link href="/privacy" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Privacy Policy
              </Link>
              <span className="text-muted-foreground">|</span>
              <span className="text-sm text-muted-foreground">NDIS Registered Provider</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
