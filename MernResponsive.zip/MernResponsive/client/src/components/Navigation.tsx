import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, Phone, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [location] = useLocation();

  const navItems = [
    { path: "/", label: "Home" },
    { path: "/about", label: "About Us" },
    { path: "/services", label: "Our Services" },
    { path: "/ndis-info", label: "NDIS Information" },
    { path: "/careers", label: "Careers" },
    { path: "/contact", label: "Contact Us" },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 border-b">
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          <Link href="/" className="flex items-center space-x-2">
            <div className="flex flex-col">
              <span className="text-xl md:text-2xl font-bold font-heading text-primary">Aegis Support</span>
              <span className="text-xs text-muted-foreground">NDIS Provider</span>
            </div>
          </Link>

          <div className="hidden lg:flex items-center space-x-1">
            {navItems.map((item) => (
              <Link key={item.path} href={item.path}>
                <Button
                  variant={location === item.path ? "secondary" : "ghost"}
                  className="font-medium"
                  data-testid={`link-nav-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  {item.label}
                </Button>
              </Link>
            ))}
          </div>

          <div className="hidden lg:flex items-center gap-4">
            <a href="tel:0435767872" className="flex items-center gap-2 text-sm text-muted-foreground hover-elevate px-3 py-2 rounded-lg transition-all">
              <Phone className="h-4 w-4" />
              <span>04 3576 7872</span>
            </a>
            <Link href="/contact">
              <Button className="rounded-full" data-testid="button-book-consultation">
                Book Consultation
              </Button>
            </Link>
          </div>

          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden p-2 hover-elevate rounded-lg"
            data-testid="button-mobile-menu"
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {isMenuOpen && (
        <div className="lg:hidden bg-background border-t">
          <div className="px-4 py-4 space-y-2">
            {navItems.map((item) => (
              <Link key={item.path} href={item.path}>
                <Button
                  variant={location === item.path ? "secondary" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setIsMenuOpen(false)}
                  data-testid={`link-mobile-nav-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  {item.label}
                </Button>
              </Link>
            ))}
            <div className="pt-4 space-y-2 border-t">
              <a href="tel:0435767872" className="flex items-center gap-2 px-4 py-2 text-sm hover-elevate rounded-lg">
                <Phone className="h-4 w-4" />
                <span>04 3576 7872</span>
              </a>
              <a href="mailto:aegis.spt@gmail.com" className="flex items-center gap-2 px-4 py-2 text-sm hover-elevate rounded-lg">
                <Mail className="h-4 w-4" />
                <span>aegis.spt@gmail.com</span>
              </a>
              <Link href="/contact">
                <Button className="w-full rounded-full" onClick={() => setIsMenuOpen(false)} data-testid="button-mobile-book">
                  Book Consultation
                </Button>
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
