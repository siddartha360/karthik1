import { 
  type User, 
  type InsertUser, 
  type ContactInquiry, 
  type InsertContactInquiry,
  type CareerApplication,
  type InsertCareerApplication
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createContactInquiry(inquiry: InsertContactInquiry): Promise<ContactInquiry>;
  getAllContactInquiries(): Promise<ContactInquiry[]>;
  createCareerApplication(application: InsertCareerApplication): Promise<CareerApplication>;
  getAllCareerApplications(): Promise<CareerApplication[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private contactInquiries: Map<string, ContactInquiry>;
  private careerApplications: Map<string, CareerApplication>;

  constructor() {
    this.users = new Map();
    this.contactInquiries = new Map();
    this.careerApplications = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createContactInquiry(inquiry: InsertContactInquiry): Promise<ContactInquiry> {
    const id = randomUUID();
    const contactInquiry: ContactInquiry = {
      ...inquiry,
      id,
      phone: inquiry.phone ?? null,
      submittedAt: new Date(),
    };
    this.contactInquiries.set(id, contactInquiry);
    return contactInquiry;
  }

  async getAllContactInquiries(): Promise<ContactInquiry[]> {
    return Array.from(this.contactInquiries.values());
  }

  async createCareerApplication(application: InsertCareerApplication): Promise<CareerApplication> {
    const id = randomUUID();
    const careerApplication: CareerApplication = {
      ...application,
      id,
      message: application.message ?? null,
      submittedAt: new Date(),
    };
    this.careerApplications.set(id, careerApplication);
    return careerApplication;
  }

  async getAllCareerApplications(): Promise<CareerApplication[]> {
    return Array.from(this.careerApplications.values());
  }
}

export const storage = new MemStorage();
