import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactInquirySchema, insertCareerApplicationSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactInquirySchema.parse(req.body);
      const inquiry = await storage.createContactInquiry(validatedData);
      
      console.log("Contact inquiry received:", {
        name: inquiry.name,
        email: inquiry.email,
        message: inquiry.message
      });
      
      res.json({ 
        success: true, 
        message: "Thank you for contacting us. We'll get back to you soon.",
        id: inquiry.id 
      });
    } catch (error) {
      console.error("Error creating contact inquiry:", error);
      res.status(400).json({ 
        success: false, 
        message: "Failed to submit inquiry. Please check your input." 
      });
    }
  });

  app.post("/api/careers/apply", async (req, res) => {
    try {
      const validatedData = insertCareerApplicationSchema.parse(req.body);
      const application = await storage.createCareerApplication(validatedData);
      
      console.log("Career application received:", {
        name: application.name,
        email: application.email,
        position: application.position
      });
      
      res.json({ 
        success: true, 
        message: "Application submitted successfully. We'll review it and get back to you soon.",
        id: application.id 
      });
    } catch (error) {
      console.error("Error creating career application:", error);
      res.status(400).json({ 
        success: false, 
        message: "Failed to submit application. Please check your input." 
      });
    }
  });

  app.get("/api/contact/inquiries", async (_req, res) => {
    try {
      const inquiries = await storage.getAllContactInquiries();
      res.json(inquiries);
    } catch (error) {
      console.error("Error fetching contact inquiries:", error);
      res.status(500).json({ error: "Failed to fetch inquiries" });
    }
  });

  app.get("/api/careers/applications", async (_req, res) => {
    try {
      const applications = await storage.getAllCareerApplications();
      res.json(applications);
    } catch (error) {
      console.error("Error fetching career applications:", error);
      res.status(500).json({ error: "Failed to fetch applications" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
